#pragma once
#include <glm/glm.hpp>

using namespace glm;

class GameObject
{
private :
	float originSize = 1.0F;
	vec3 scale;
	vec3 position;
	virtual void drawGeometry();
	void drawOrigin();

public:
	void SetScale(float x, float y, float z);
	void setPosition(float x, float y, float z);
	void draw();
};