var searchData=
[
  ['context_20reference_760',['Context reference',['../group__context.html',1,'']]]
];
