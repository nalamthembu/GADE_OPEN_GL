﻿#include "GameObject.h"
#include <GL/freeglut.h>
#include <iostream>
#include "Settings.h"

void GameObject::drawGeometry()
{
	printf("Inherited member not implemented");
}

void GameObject::drawOrigin()
{
	glDisable(GL_DEPTH_TEST);

		glBegin(GL_LINES);
		{
			//X-AXIS
			glColor3f(1, 0, 0);
			glVertex3f(0, 0, 0);
			glVertex3f(originSize, 0, 0);

			//Y-AXIS
			glColor3f(0, 1, 0);
			glVertex3f(0, 0, 0);
			glVertex3f(0, originSize, 0);

			//Z-AXIS
			glColor3f(0, 0, 1);
			glVertex3f(0, 0, 0);
			glVertex3f(0, 0, originSize);
		}
		glEnd();



			//X-CONE
			glPushMatrix();
			{
				glColor3f(1, 0, 0);
				glTranslatef(originSize, 0, 0);
				glRotatef(90, 0, 1, 0);
				glutSolidCone(0.05f, 0.2F, 8, 1);
			}
			glPopMatrix();

			//Y-CONE
			glPushMatrix();
			{
				glColor3f(0, 1, 0);
				glTranslatef(0, originSize, 0);
				glRotatef(-90, 1, 0, 0);
				glutSolidCone(0.05f, 0.2F, 8, 1);
			}
			glPopMatrix();

			//Z-CONE - NEEDS WORK
			glPushMatrix();
			{
				glColor3f(0, 0, 1);
				glTranslatef(0, originSize, 0);
				glRotatef(-90, 1, 0, 0);
				glutSolidCone(0.05f, 0.2F, 8, 1);
			}
			glPopMatrix();

		


	glEnable(GL_DEPTH_TEST);
}

void GameObject::SetScale(float x, float y, float z)
{
	scale = vec3(x, y, z);
}

void GameObject::setPosition(float x, float y, float z)
{
	position = vec3(x, y, z);
}

void GameObject::draw()
{
	glPushMatrix();
	{
		glTranslatef(position.x, position.y, position.z);


		if (scale.x <= 0 || scale.y <= 0 || scale.z <= 0)
		{
			scale = vec3(1, 1, 1);
		}

		glScalef(scale.x, scale.y, scale.z);


		drawGeometry();

		if (Settings::IsInDebugMode)
			drawOrigin();
	}
	glPopMatrix();
}