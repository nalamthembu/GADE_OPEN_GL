#pragma once

struct Pixel
{
	//information for the Pixels- storing the colours (RGB) and transparency (alpha)
	float r;
	float g;
	float b;
	float a;
};

