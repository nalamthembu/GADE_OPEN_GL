#include <GL/freeglut.h>
#include <vector>
#include <string>
#include "Texture_c.h"

class Terrain_c {
public:
    Terrain_c(const std::string& heightmapFile, const std::string& textureFile, float scale, float height) {
        LoadHeightmap(heightmapFile);
        LoadTexture(textureFile);
        ScaleTerrain(scale, height);
    }

    void Render() {
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, texture.GetID());

        glBegin(GL_TRIANGLES);
        for (int i = 0; i < heightmapSize - 1; i++) {
            for (int j = 0; j < heightmapSize - 1; j++) {
                DrawQuad(i, j);
            }
        }
        glEnd();

        glDisable(GL_TEXTURE_2D);
    }

private:
    std::vector<std::vector<float>> heightmap;
    Texture_c texture;
    int heightmapSize;
    float terrainScale;
    float terrainHeight;

    void LoadHeightmap(const std::string& heightmapFile) {
        // Load heightmap data from the file and populate the 'heightmap' vector
        // You can use image loading libraries like FreeImage or SOIL
    }

    void LoadTexture(const std::string& textureFile) {
        texture.Load(textureFile);
    }

    void ScaleTerrain(float scale, float height) {
        terrainScale = scale;
        terrainHeight = height;

        // Apply scaling to the 'heightmap' data
        for (int i = 0; i < heightmapSize; i++) {
            for (int j = 0; j < heightmapSize; j++) {
                heightmap[i][j] *= scale;
            }
        }
    }

    void DrawQuad(int i, int j) {
        // Calculate vertices and texture coordinates for the quad
        // Apply the scaling and height transformation

        float x0 = i * terrainScale;
        float x1 = (i + 1) * terrainScale;
        float y0 = heightmap[i][j] * terrainHeight;
        float y1 = heightmap[i + 1][j] * terrainHeight;
        float z0 = j * terrainScale;
        float z1 = (j + 1) * terrainScale;

        float s0 = static_cast<float>(i) / heightmapSize;
        float s1 = static_cast<float>(i + 1) / heightmapSize;
        float t0 = static_cast<float>(j) / heightmapSize;
        float t1 = static_cast<float>(j + 1) / heightmapSize;

        // Draw the quad using the above information
        glTexCoord2f(s0, t0); glVertex3f(x0, y0, z0);
        glTexCoord2f(s0, t1); glVertex3f(x0, y1, z1);
        glTexCoord2f(s1, t1); glVertex3f(x1, y1, z1);

        glTexCoord2f(s0, t0); glVertex3f(x0, y0, z0);
        glTexCoord2f(s1, t1); glVertex3f(x1, y1, z1);
        glTexCoord2f(s1, t0); glVertex3f(x1, y0, z0);
    }
};