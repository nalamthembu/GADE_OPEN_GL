#pragma once
#include "GameObject.h"
#include <vector>
#include "GL/glew.h"
#include "glm/glm.hpp"
#include "TextureManager.h"
#include "Texture_c.h"

using namespace glm;

class Terrain : public GameObject
{
public:
	
	Terrain(Texture* heightMapTexture, float size, float height, const char* texturePath);

private:
	int size, height;
	Texture* heightMap;
	Texture_c* albedo;
	void drawGeometry() override;
};