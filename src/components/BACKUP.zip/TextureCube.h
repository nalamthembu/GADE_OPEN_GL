#pragma once
#include "GameObject.h"

class TextureCube : public GameObject
{
	private:
		void drawGeometry() override;
};